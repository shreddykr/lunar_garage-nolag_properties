Thank you for downloading. Please follow the install instructions below.
I DID NOT create Lunar_Garage just integrated NoLag to work with it!
Lunar Scripts Discord: https://discord.gg/zTz5xFye8g
NoLag Discord: https://discord.gg/nolagdev

1) Download and install the latest version of NoLag Properties or purchase if you havent already. 

2) Download and install the latest version of lunar_garage following the install docs they provided

3) Next run the sql file in the servers database

4) Replace the files included in the lunar_garage resource 

5) Place the lunar_garage.lua file in the Garage folder (NoLag_Properties:Custom:Garage)
